var p=document.querySelector(".para");
p.innerHTML="My  name is <b>Alisha Dawood</b>";
p.style.fontSize="30px";
