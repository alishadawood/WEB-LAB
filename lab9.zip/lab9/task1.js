var p=document.querySelector(".para");
p.innerHTML="Alisha Dawood";
p.style.color="blue";
p.style.fontSize="30px";
