var p=document.querySelector(".para");
p.textContent="Alisha Dawood";
p.style.fontSize="30px";
