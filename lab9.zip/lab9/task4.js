const p=document.querySelectorAll('li');
p.forEach(items=>{
items.textContent=items.textContent.toUpperCase();
});
