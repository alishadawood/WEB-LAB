const countVowels = (str) => {
    str = str.toLowerCase();
    let vowels = "aeiou";
    let count = 0;

    for (let char of str) {
        if (vowels.includes(char)) {
            count++;
        }
    }
    return count;
};
console.log("Vowels in Alisha:", countVowels("Alisha"));
console.log("Vowels in Pakistan:", countVowels("Pakistan"));

