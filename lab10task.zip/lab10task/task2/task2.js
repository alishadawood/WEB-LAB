let btn = document.createElement("button");
btn.textContent = "logIn";
btn.style.color = "white";
btn.style.backgroundColor = "pink";
document.documentElement.insertBefore(btn, document.body);