let bigInt = 123456789101112131415161718;
console.log(typeof bigInt); 
let num = "2005";
console.log(typeof num); 
let converted = Number(num); 
console.log(typeof converted); 
console.log(Number("45")); 


const Product = {
  id: 11,
  name: "Glass Cleaner",
  brand: "PakWheels",
  orgPrice: 1108,
  inStock: true,
  disCount:20,
  disPrice:958

};

console.log(Product);


const InstProfile = {
  username: "alishaqureshi16",
  followers: 92,
  following: 103,
  posts: 0,
  bio: "Kashmiri soul|BSCS@Riphah,Islambad|Blooming in silence,glowing in code",
  isVerified: false
};

console.log(InstProfile);

var a = 6;

console.log(a++);
console.log(a);
var a=9;
console.log(++a);
var a=10;
console.log(a--); 
console.log(a);
var a=5;
console.log(--a); 

