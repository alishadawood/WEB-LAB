console.log("web App dev");
a=null;
y=undefined;
console.log(y);
console.log(a);
var name="Alisha";
console.log(name);
var name="Arfa";
console.log(name);
var name="saran";
console.log(name);
if(true){
    var test="inside block";
}
console.log(test);
let age = 25;
console.log(age); // Output: 25

age = 30; // Updating allowed
console.log(age); // Output: 30

if (true) {
    let insideBlock = "Hello";
    console.log(insideBlock); // Output: Hello
}
//console.log(insideBlock); 
    var time=prompt("hey whats the time:");
    if(time>5&&time<17){
        alert("good morning");



    }
    else{
    alert("good morning");
        
    }
