const toSeconds = (minutes) => {
  return minutes * 60;
};
console.log("2 minutes =", toSeconds(2), "seconds");
