let numbers = [1, 3, 7, 9];

let product = numbers.reduce(function(acc, num) {
  return acc * num;
}, 1);
console.log("Product of all numbers is:", product);
