var numbers = [2, 3, 4, 5, 6];
numbers.forEach(function(num) {
  console.log("Square of", num, "is", num * num);
});
